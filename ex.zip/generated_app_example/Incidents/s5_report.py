import streamlit as st

st.header("Close & archive Incident")