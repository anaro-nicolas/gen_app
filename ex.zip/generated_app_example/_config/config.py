DB_HOST = 'localhost'
DB_PORT = 9000
DB_NAME = 'database_1854'
DB_USER = '*************'
DB_PASSWORD = '********'
DB_PATH = 'generate_app/_db/***********.sqlite'
