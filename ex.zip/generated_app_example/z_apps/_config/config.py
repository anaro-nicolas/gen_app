import os
from pathlib import Path

# Chemin vers la base de données
DB_PATH = 'generate_app/_db/database_30756.sqlite'


DB_HOST = 'localhost'
DB_PORT = 9000
DB_NAME = 'database_30756'
DB_USER = 'user_12421'
DB_PASSWORD = 'ubuNPdpg060e5Msw'
